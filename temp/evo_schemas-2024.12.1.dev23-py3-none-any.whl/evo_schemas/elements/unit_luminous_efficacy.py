import enum


class UnitLuminousEfficacy_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_lm_per_W = "lm/W"
