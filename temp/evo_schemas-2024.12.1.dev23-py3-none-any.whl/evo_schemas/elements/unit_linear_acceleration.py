import enum


class UnitLinearAcceleration_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_Gal = "Gal"
    Unit_gn = "gn"
    Unit_m_per_s2 = "m/s2"
    Unit_cm_per_s2 = "cm/s2"
    Unit_ft_per_s2 = "ft/s2"
    Unit_in_per_s2 = "in/s2"
    Unit_mGal = "mGal"
    Unit_mgn = "mgn"
