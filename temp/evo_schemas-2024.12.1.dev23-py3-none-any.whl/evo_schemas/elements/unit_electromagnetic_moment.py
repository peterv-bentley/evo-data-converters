import enum


class UnitElectromagneticMoment_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_A_m2 = "A.m2"
