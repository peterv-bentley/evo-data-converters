import enum


class UnitAmountOfSubstancePerTime_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_mol_per_s = "mol/s"
    Unit_kmol_per_h = "kmol/h"
    Unit_kmol_per_s = "kmol/s"
    Unit_lbmol_per_h = "lbmol/h"
    Unit_lbmol_per_s = "lbmol/s"
