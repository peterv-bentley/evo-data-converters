import enum


class UnitIlluminance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_lx = "lx"
    Unit_footcandle = "footcandle"
    Unit_lm_per_m2 = "lm/m2"
    Unit_klx = "klx"
