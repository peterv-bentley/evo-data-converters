import enum


class UnitQuantityOfLight_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_lm_s = "lm.s"
