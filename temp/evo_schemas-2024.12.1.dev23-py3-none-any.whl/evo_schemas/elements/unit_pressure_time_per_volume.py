import enum


class UnitPressureTimePerVolume_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_Pa_s_per_m3 = "Pa.s/m3"
    Unit_psi_d_per_bbl = "psi.d/bbl"
