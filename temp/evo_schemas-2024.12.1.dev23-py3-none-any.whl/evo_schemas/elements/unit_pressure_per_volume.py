import enum


class UnitPressurePerVolume_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_Pa_per_m3 = "Pa/m3"
    Unit_psi2_d_per_cP_ft3 = "psi2.d/(cP.ft3)"
