import enum


class UnitThermalResistance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_deltaK_per_W = "deltaK/W"
