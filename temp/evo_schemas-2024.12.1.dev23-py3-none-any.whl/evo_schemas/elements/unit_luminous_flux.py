import enum


class UnitLuminousFlux_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_lm = "lm"
