import enum


class UnitAreaPerAmountOfSubstance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_m2_per_mol = "m2/mol"
