import enum


class UnitReciprocalElectricPotentialDifference_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_1_per_uV = "1/uV"
    Unit_1_per_V = "1/V"
