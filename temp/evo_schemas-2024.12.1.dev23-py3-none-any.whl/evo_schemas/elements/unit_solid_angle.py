import enum


class UnitSolidAngle_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_sr = "sr"
