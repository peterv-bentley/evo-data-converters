import enum


class UnitReciprocalForce_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_1_per_lbf = "1/lbf"
    Unit_1_per_N = "1/N"
