import enum


class UnitTimePerMass_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_s_per_kg = "s/kg"
