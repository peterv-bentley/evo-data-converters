import enum


class UnitMagneticPermeability_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_uH_per_m = "uH/m"
    Unit_H_per_m = "H/m"
