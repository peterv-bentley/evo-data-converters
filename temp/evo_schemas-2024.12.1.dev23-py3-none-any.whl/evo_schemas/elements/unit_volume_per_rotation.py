import enum


class UnitVolumePerRotation_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_m3_per_rad = "m3/rad"
    Unit_ft3_per_rad = "ft3/rad"
    Unit_m3_per_rev = "m3/rev"
