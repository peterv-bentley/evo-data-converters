import enum


class UnitPermittivity_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_uF_per_m = "uF/m"
    Unit_F_per_m = "F/m"
