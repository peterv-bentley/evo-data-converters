import enum


class UnitAreaPerMass_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_m2_per_kg = "m2/kg"
    Unit_cm2_per_g = "cm2/g"
    Unit_ft2_per_lbm = "ft2/lbm"
    Unit_m2_per_g = "m2/g"
