import enum


class UnitLuminousIntensity_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_cd = "cd"
    Unit_kcd = "kcd"
