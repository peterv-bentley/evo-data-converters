import enum


class UnitElectricConductance_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_S = "S"
    Unit_cS = "cS"
    Unit_dS = "dS"
    Unit_ES = "ES"
    Unit_fS = "fS"
    Unit_GS = "GS"
    Unit_kS = "kS"
    Unit_mS = "mS"
    Unit_MS = "MS"
    Unit_nS = "nS"
    Unit_pS = "pS"
    Unit_TS = "TS"
    Unit_uS = "uS"
