import enum


class UnitMagneticVectorPotential_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_Wb_per_m = "Wb/m"
    Unit_Wb_per_mm = "Wb/mm"
