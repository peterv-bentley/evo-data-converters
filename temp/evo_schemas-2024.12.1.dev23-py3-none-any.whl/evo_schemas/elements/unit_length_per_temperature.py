import enum


class UnitLengthPerTemperature_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_m_per_deltaK = "m/deltaK"
    Unit_ft_per_deltaF = "ft/deltaF"
