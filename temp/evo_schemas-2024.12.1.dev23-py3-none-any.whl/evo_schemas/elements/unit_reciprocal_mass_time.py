import enum


class UnitReciprocalMassTime_V1_0_1_UnitCategories(str, enum.Enum):
    Unit_1_per_kg_s = "1/(kg.s)"
    Unit_pCi_per_g = "pCi/g"
    Unit_Bq_per_kg = "Bq/kg"
